const escapeHtml = window.markdownit().utils.escapeHtml;
// ::: details Detail
//   summary comes here
// :::
export const containerDetailsOptions = {
    validate: function (params) {
        return /^details\s+(.*)$/.test(params.trim());
    },
    render: function (tokens, idx) {
        const m = tokens[idx].info.trim().match(/^details\s+(.*)$/);
        const summary = m?.[1] || '';
        if (tokens[idx].nesting === 1) {
            // opening tag
            return (
                '<details><summary>' +
                escapeHtml(summary) +
                '</summary><div class="details-content">'
            );
        } else {
            // closing tag
            return '</div></details>\n';
        }
    },
};

// ::: message alert
//   text
// :::
const msgClassRegex = /^message\s*(alert)?$/;

export const containerMessageOptions = {
    validate: function (params) {
        return msgClassRegex.test(params.trim());
    },
    render: function (tokens, idx) {
        const m = tokens[idx].info.trim().match(msgClassRegex);
        const msgClassName = m?.[1] || '';

        if (tokens[idx].nesting === 1) {
            // opening tag
            return '<div class="msg ' + escapeHtml(msgClassName) + '">';
        } else {
            // closing tag
            return '</div>\n';
        }
    },
};