import { loadLanguages } from '../libs/prism/components/index.js';

const Prism = window.Prism;
const escapeHtml = window.markdownit().utils.escapeHtml;

function loadPrismGrammer(lang) {
    if (!lang) return undefined;
    let langObject = Prism.languages[lang];
    if (langObject === undefined) {
        loadLanguages([lang]);
        langObject = Prism.languages[lang];
    }
    return langObject;
}

function highlightContent({text,prismGrammer,langName,hasDiff}) {
    if (prismGrammer && langName) {
        if (hasDiff) return Prism.highlight(text, Prism.languages.diff, `diff-${langName}`);
        return Prism.highlight(text, prismGrammer, langName);
    }

    if (hasDiff) return Prism.highlight(text, Prism.languages.diff, 'diff');
    return escapeHtml(text);
}

export function highlight(
    text,
    langName,
    hasDiff
) {
    const prismGrammer = loadPrismGrammer(langName);
    return highlightContent({ text, prismGrammer, langName, hasDiff });
}