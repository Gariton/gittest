const markdownIt = window.markdownit;

import { containerDetailsOptions, containerMessageOptions } from './utils/md-container.js';
import { mdRendererFence } from './utils/md-renderer-fence.js';
import { mdLinkifyToCard } from './utils/md-linkify-to-card.js';
// import { mdKatex } from './utils/md-katex.js';
import mdKatex from './libs/markdown-it-mdKatex/markdown-it-mdKatex.js';
import { mdBr } from './utils/md-br.js';
import { mdCustomBlock } from './utils/md-custom-block.js';
const markdownItImSize = window['markdown-it-imsize.js'];
import markdownItAnchor from '../src/libs/markdown-it-anchor/markdown-it-anchor.js';
const mdContainer = window.markdownitContainer;
const mdFootnote = window.markdownitFootnote;
const mdTaskLists = window.markdownitTaskLists;
const mdInlineComments = window.markdownitInlineComments;
const mdLinkAttributes = window.markdownitLinkAttributes;

const md = markdownIt({
    breaks: true,
    linkify: true
});

md.linkify.set({ fuzzyLink: false });

md.use(mdBr)
    .use(mdRendererFence)
    .use(markdownItImSize)
    .use(mdCustomBlock)
    .use(mdContainer, 'details', containerDetailsOptions)
    .use(mdContainer, 'message', containerMessageOptions)
    .use(mdFootnote)
    .use(mdTaskLists, { enabled: true })
    .use(mdInlineComments)
    .use(mdLinkAttributes, {
        pattern: /^(?!https:\/\/zenn\.dev\/)/,
        attrs: {
        rel: 'nofollow',
        },
    })
    .use(markdownItAnchor, {
        level: [1, 2, 3, 4],
        permalink: markdownItAnchor.permalink.ariaHidden({
            placement: 'before',
            class: 'header-anchor-link',
            symbol: '',
        }),
        tabIndex: false,
    })
    .use(mdKatex)
    .use(mdLinkifyToCard);

md.renderer.rules.footnote_block_open = () => 
    '<section class="footnotes">\n' +
    '<div class="footnotes-title">脚注</div>\n' +
    '<ol class="footnotes-list">\n';

export function markdownToHtml (text) {
    if (!(text && text.length)) return '' ;
    return md.render(text); 
}