import { markdownToHtml } from '../src/index.js';

(async () => {
    const mdFile = await $.ajax('./pages/zenn-markdown.md');
    const htmlData = markdownToHtml(mdFile);

    document.getElementById('app').innerHTML = htmlData;
})();